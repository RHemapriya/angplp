import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CartRouterModule } from './cart-router.module';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { DebitCardDetailsComponent } from './debit-card-details/debit-card-details.component';


@NgModule({
  declarations: [
    AppComponent,
    AddToCartComponent,
    WishlistComponent,
    PaymentComponent,
    PaymentCardDetailsComponent,
    DebitCardDetailsComponent,
    
  ],
  imports: [
    BrowserModule,
    CartRouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
