import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CODComponent } from './cod.component';

describe('CODComponent', () => {
  let component: CODComponent;
  let fixture: ComponentFixture<CODComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CODComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CODComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
