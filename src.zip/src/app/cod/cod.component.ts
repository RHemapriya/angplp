import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cod',
  templateUrl: './cod.component.html',
  styleUrls: ['./cod.component.css']
})
export class CODComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
