import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-debit-card-details',
  templateUrl: './debit-card-details.component.html',
  styleUrls: ['./debit-card-details.component.css']
})
export class DebitCardDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
