import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{RouterModule,Routes} from '@angular/router';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { DebitCardDetailsComponent } from './debit-card-details/debit-card-details.component';


const routes:Routes=[
  {
    path:'app-add-to-cart',
    component:AddToCartComponent
  },
  {
    path:'app-wishlist',
    component:WishlistComponent
  },
  {
    path:'app-payment',
    component:PaymentComponent
  },
  {
    path:'app-payment-card-details',
    component:PaymentCardDetailsComponent
  },
  {
    path:'app-debit-card-details',
    component:DebitCardDetailsComponent
  }
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule],
})
export class CartRouterModule { }
