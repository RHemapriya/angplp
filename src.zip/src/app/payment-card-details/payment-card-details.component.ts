import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-card-details',
  templateUrl: './payment-card-details.component.html',
  styleUrls: ['./payment-card-details.component.css']
})
export class PaymentCardDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
