import { CartRouterModule } from './cart-router.module';

describe('CartRouterModule', () => {
  let cartRouterModule: CartRouterModule;

  beforeEach(() => {
    cartRouterModule = new CartRouterModule();
  });

  it('should create an instance', () => {
    expect(cartRouterModule).toBeTruthy();
  });
});
